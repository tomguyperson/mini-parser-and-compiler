//
//  ViewController.swift
//  lab1
//
//  Created by Tommy Mesquita on 1/30/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

