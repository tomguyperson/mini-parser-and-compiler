//
//  City+CoreDataClass.swift
//  tableViewCoreData
//
//  Created by Tommy Mesquita on 3/16/22.
//  Copyright © 2022 ASU. All rights reserved.
//

import Foundation
import CoreData


public class City: NSManagedObject {

}
